
requirejs.config({
    "baseUrl":"js",
    "paths":{
        //Libs
        "Class":"libs/class",
        "Jquery":"libs/jquery",
        //Classes

        "Display":"app/classes/display/Display",
        "Game":"app/classes/Game",
        "KeyManager":"app/classes/Input/KeyManager",
        "Launcher":"app/classes/Launcher",
        "Handler":"app/classes/Handler",
        "ImageLoader": "app/classes/gfx/ImageLoader",
        "SpriteSheet": "app/classes/gfx/SpriteSheet",
        "Assets": "app/classes/gfx/Assets",
        "State": "app/classes/states/state",
        "GameState": "app/classes/states/gameOfState",
        "Terrain": "app/classes/Terrain/Terrain",
        "CreateTerrains": "app/classes/Terrain/CreateTerrains",
        "Map": "app/classes/Terrain/Map",
        "Timer": "app/classes/timer/timer",
        "Levels": "app/classes/Terrain/Levels"
    }
});

require(['app/main']);
