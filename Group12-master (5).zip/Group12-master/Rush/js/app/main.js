

require(['Launcher'],function(Launcher){

    localStorage.setItem("current_level", '1');
    var launcher = new Launcher("Rush",800,800);
});