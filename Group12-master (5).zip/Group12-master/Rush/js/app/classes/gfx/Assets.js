
define(['Class', 'ImageLoader', 'SpriteSheet'], function(Class, ImageLoader, SpriteSheet)
{
    //Creates the Assets from the sprite sheets
    var default_width = 32;
    var default_height = 32;
    var assets = {};
    var sheet;
    var Assets = Class.extend({
        init:function(name1, path1, width1, height1)
        {
            assets[name1] = this;
            this.name = name1;
            this.path = path1;
            this.width = width1;
            this.height = height1;
            this.sheet = new SpriteSheet(ImageLoader.loadImage(this.path));
        }
    });

    Assets.default_width = default_width;
    Assets.default_height = default_height;
    Assets.getAssets = function(name1){
        return assets[name1];
    };
    //width of Player is 29 height of Player is 32
    var asset = new Assets("pikachu", "res/textures/pikachusprites.png", 29, 32);
    asset.idle = asset.sheet.crop(0,0,29,32);

    // Creating terrain walk and safe-zone image assets
    var terrains = new Assets("terrains", "res/textures/terrain.png", 64, 64);
    terrains.walk = terrains.sheet.crop(0, terrains.height * 1, terrains.width, terrains.height);
    terrains.safezone = terrains.sheet.crop(terrains.width * 8, terrains.height * 1, terrains.width, terrains.height);
    terrains.barrier = terrains.sheet.crop(terrains.width * 8, terrains.height * 0, terrains.width, terrains.height);

    //Monster sprites
    //monster is also with width of 29 and height of 32
    var raichu = new Assets("raichu", "res/textures/raichu.png", 65, 53);
    raichu.monster = raichu.sheet.crop(0,0,65,53);
    var sandshrew = new Assets("sandshrew", "res/textures/sandshrew.png", 29, 37);
    sandshrew.monster = sandshrew.sheet.crop(0,0,29,37);
    var charmander = new Assets("charmander", "res/textures/charmander.png",29,37);
    charmander.monster = charmander.sheet.crop(0,0,39,42);
    var squirtle = new Assets("squirtle", "res/textures/squirtle.png",29,37);
    squirtle.monster = squirtle.sheet.crop(0,0,38,37);
    var marowak = new Assets("marowak", "res/textures/marowak.png",55,50);
    marowak.monster = marowak.sheet.crop(0,0,55,50);
    var charizard = new Assets("charizard", "res/textures/charizard.png",70,70);
    charizard.monster = charizard.sheet.crop(3,4,114,74);

    //Item Sprites
    var watermelon = new Assets("watermelon", "res/textures/items.png",25,22);
    watermelon.item = watermelon.sheet.crop(838,397,50,44);
    var pinkPowder = new Assets("pinkPowder", "res/textures/items.png", 25, 22);
    pinkPowder.item = pinkPowder.sheet.crop(963, 326, 57, 52);
    var purplePowder = new Assets("purplePowder", "res/textures/items.png", 25, 22);
    purplePowder.item = purplePowder.sheet.crop(958,592,65,44);
    var cake = new Assets("cake", "res/textures/items.png", 25, 22);
    cake.item = cake.sheet.crop(834, 66, 61, 54);
    var carrot = new Assets("carrot", "res/textures/items.png", 25, 22);
    carrot.item = carrot.sheet.crop(514, 455, 57,50);
    var apple = new Assets("apple", "res/textures/items.png", 25, 22);
    apple.item = apple.sheet.crop(638,5,63,60);
    var gapple = new Assets("gapple", "res/textures/items.png", 25, 22);
    gapple.item = gapple.sheet.crop(704,4,63,60);
    var chicken = new Assets("chicken", "res/textures/items.png", 25, 22);
    chicken.item = chicken.sheet.crop(641,449,56,52);
    var rchicken = new Assets("rchicken", "res/textures/items.png", 25, 22);
    rchicken.item = rchicken.sheet.crop(577,449,56,52);
    return Assets;
});
