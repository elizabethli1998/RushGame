
define(['Class'], function(Class){
    var SpriteSheet = Class.extend({
        init: function(_sheet)
        {
            this.sheet = _sheet;
        },
        crop: function(x1, y1, width1, height1){
        return {"sheet":this.sheet, "x": x1, "y": y1, "width": width1, "height": height1};
    }
    });
    return SpriteSheet;
});
