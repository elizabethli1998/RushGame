
define(['State', 'Timer', 'Assets', 'Map'], function(State, Timer, Assets, Map)
{
    var GameState = State.extend({
        init:function(_handler)
        {
            this._super(_handler);
            this.map = new Map();

        }
    });
    //Player and Monsters
    var pikachuX = 0;
    var pikachuY = 0;
    var raichuX = 417;
    var raichuY = 390;
    var charmanderX = 417;
    var charmanderY = 290;
    var sandShrewX = 40;
    var sandShrewY = 40;
    var squirtleX = 0;
    var squirtleY = 800;
    var charizardX = 100;
    var charizardY = 700;
    var marowakX = Math.floor((Math.random() * 800) + 1);
    var marowakY = Math.floor((Math.random() * 800) + 1);
    //Items
    var pinkPowderX= Math.floor((Math.random() * 800) + 10);
    var pinkPowderY = Math.floor((Math.random() * 800) + 10);
    var purplePowderX= Math.floor((Math.random() * 800) + 10);
    var purplePowderY = Math.floor((Math.random() * 800) + 10);
    var cakeX = Math.floor((Math.random() * 700) + 10);
    var cakeY = Math.floor((Math.random() * 700) + 10);
    var carrotX = Math.floor((Math.random() * 700) + 10);
    var carrotY = Math.floor((Math.random() * 700) + 10);
    var appleX = Math.floor((Math.random() * 600) + 10);
    var appleY = Math.floor((Math.random() * 600) + 10);
    var gappleX = Math.floor((Math.random() * 600) + 10);
    var gappleY = Math.floor((Math.random() * 600) + 10);
    var chickenX = Math.floor((Math.random() * 500) + 10);
    var chickenY = Math.floor((Math.random() * 500) + 10);
    var rchickenX = Math.floor((Math.random() * 500) + 10);
    var rchickenY = Math.floor((Math.random() * 500) + 10);
    var watermelonX = localStorage.getItem("width")/2;
    var watermelonY = localStorage.getItem("height")/2;

    //Stats
    var health = localStorage.getItem("health");
    var currentSpeed = localStorage.getItem("speed");

    GameState.prototype.tick = function(_dt) {
        itemCollide();
        // Handles 'w' key
        if (this.handler.getKeyManager().up) {
            // Variables 'check_x_tile' and 'check_y_tile' are created to reflect proper x and y coordinates in the
            // matrix, map. This is because we are working with pixels
            let check_x_tile = parseInt(pikachuX / 32);
            let check_y_tile = parseInt(Math.max(0, pikachuY - 30 * _dt) / 32);

            // Checks if (check_x_tile, check_y_tile) coordinate is a barrier. This is done in the scenario that the
            // player is after the barrier tile
            if (this.map.map[check_x_tile][check_y_tile] === "barrier") {
                pikachuY = (check_y_tile * 32) + 32;
            }
            // Because player moves by pixels, we need make a check if (check_x_tile + 1, check_y_tile) coordinate is a
            // barrier. This is done in the scenario that the player is before the barrier tile
            else if (parseInt(Math.max(0, pikachuY) % 32) === 0 && parseInt(pikachuX) % 32 !== 0 &&
                check_x_tile + 1 < 25 && this.map.map[check_x_tile + 1][check_y_tile] === "barrier") {
                pikachuY = (check_y_tile * 32) + 32;
            }
            // The program moves player normally
            else {

                pikachuY = Math.max(0, pikachuY - currentSpeed * _dt);

            }
            sandShrewY = Math.max(0, sandShrewY - 30 * _dt);

            //Displays the coordinates of the player
            displayCoor(check_x_tile, check_y_tile);

            //Checks for the safezone
            if (this.map.map[check_x_tile][check_y_tile] === "Safe-Zone") {
                let level = localStorage.getItem("current_level");
                if (level === localStorage.getItem("max_levels")){
                    displayWin();
                }
                else{
                    level++;
                    localStorage.setItem("current_level", level);
                    this.map = new Map();
                    pikachuX = 0;
                    pikachuY = 0;
                    sandShrewX = 40;
                    sandShrewY = 40;
                }
            }
        }
        // Handles 's' key
        else if (this.handler.getKeyManager().down) {
            // Variables 'check_x_tile' and 'check_y_tile' are created to reflect proper x and y coordinates in the
            // matrix, map. This is because we are working with pixels
            let check_x_tile = parseInt(pikachuX / 32);
            let check_y_tile = parseInt(Math.min(pikachuY + 30 * _dt, 800 - 32) / 32);

            // Checks if (check_x_tile, check_y_tile) coordinate is a barrier. This is done in the scenario that the
            // player is after the barrier tile
            if (check_y_tile + 1 < 25 && this.map.map[check_x_tile][check_y_tile + 1] === "barrier") {
                pikachuY = check_y_tile * 32;
            }
            // Because player moves by pixels, we need make a check if (check_x_tile + 1, check_y_tile) coordinate is a
            // barrier. This is done in the scenario that the player is before the barrier tile
            else if (parseInt(Math.max(0, pikachuY) % 32) === 0 && parseInt(pikachuX) % 32 !== 0 &&
                check_x_tile + 1 < 25 && check_y_tile + 1 < 25 &&
                this.map.map[check_x_tile + 1][check_y_tile + 1] === "barrier") {
                pikachuY = check_y_tile * 32;
            }
            // The program moves player normally
            else {
                pikachuY = Math.min(pikachuY + currentSpeed * _dt, 800 - 32);
            }
            sandShrewY = Math.min(sandShrewY + 30 * _dt, 800 - 37);

            //Displays the coordinates of the player
            displayCoor(check_x_tile, check_y_tile);

            //Checks for the safezone
            if (this.map.map[check_x_tile][check_y_tile] === "Safe-Zone") {
                let level = localStorage.getItem("current_level");
                if (level === localStorage.getItem("max_levels")){
                    displayWin();
                }
                else{
                    level++;
                    localStorage.setItem("current_level", level);
                    this.map = new Map();
                    pikachuX = 0;
                    pikachuY = 0;
                    sandShrewX = 40;
                    sandShrewY = 40;
                }
            }
        }
        // Handles 'a' key
        else if (this.handler.getKeyManager().left) {
            // Variables 'check_x_tile' and 'check_y_tile' are created to reflect proper x and y coordinates in the
            // matrix, map. This is because we are working with pixels
            let check_x_tile = parseInt(Math.max(0, pikachuX - 30 * _dt) / 32);
            let check_y_tile = parseInt(pikachuY / 32);

            // Checks if (check_x_tile, check_y_tile) coordinate is a barrier. This is done in the scenario that the
            // player is after the barrier tile
            if (this.map.map[check_x_tile][check_y_tile] === "barrier") {
                pikachuX = (check_x_tile * 32) + 32;
            }
            // Because player moves by pixels, we need make a check if (check_x_tile + 1, check_y_tile) coordinate is a
            // barrier. This is done in the scenario that the player is before the barrier tile
            else if (parseInt(Math.max(0, pikachuX) % 32) === 0 && parseInt(pikachuY) % 32 !== 0 &&
                this.map.map[check_x_tile][check_y_tile + 1] === "barrier") {
                pikachuX = (check_x_tile * 32) + 32;
            }
            // The program moves player normally
            else {
                pikachuX = Math.max(0, pikachuX - currentSpeed * _dt);

            }
            sandShrewX = Math.max(0, sandShrewX - 30 * _dt);

            //Displays the coordinates of the player
            displayCoor(check_x_tile, check_y_tile);

            //Checks for the safezone
            if (this.map.map[check_x_tile][check_y_tile] === "Safe-Zone") {
                let level = localStorage.getItem("current_level");
                if (level === localStorage.getItem("max_levels")){
                    displayWin();
                }
                else{
                    level++;
                    localStorage.setItem("current_level", level);
                    this.map = new Map();
                    pikachuX = 0;
                    pikachuY = 0;
                    sandShrewX = 40;
                    sandShrewY = 40;
                }
            }
        }
        // Handles 'd' key
        else if (this.handler.getKeyManager().right) {
            // Variables 'check_x_tile' and 'check_y_tile' are created to reflect proper x and y coordinates in the
            // matrix, map. This is because we are working with pixels
            let check_x_tile = parseInt(Math.min(pikachuX + 30 * _dt, 800 - 30) / 32);
            let check_y_tile = parseInt(pikachuY / 32);

            // Checks if (check_x_tile, check_y_tile) coordinate is a barrier. This is done in the scenario that the
            // player is after the barrier tile
            if (check_x_tile + 1 < 25 && this.map.map[check_x_tile + 1][check_y_tile] === "barrier") {
                pikachuX = check_x_tile * 32;
            }
            // Because player moves by pixels, we need make a check if (check_x_tile + 1, check_y_tile) coordinate is a
            // barrier. This is done in the scenario that the player is before the barrier tile
            else if (parseInt(Math.max(0, pikachuX) % 32) === 0 && parseInt(pikachuY) % 32 !== 0 &&
                check_x_tile + 1 < 25 && this.map.map[check_x_tile + 1][check_y_tile + 1] === "barrier") {
                pikachuX = check_x_tile * 32;
            }
            // The program moves player normally
            else {
                pikachuX = Math.min(pikachuX + currentSpeed * _dt, 800 - 30);

            }
            sandShrewX = Math.min(sandShrewX +30 * _dt, 800 - 29);

            //Displays the coordinates of the player
            displayCoor(check_x_tile, check_y_tile);

            //Checks for the safezone
            if (this.map.map[check_x_tile][check_y_tile] === "Safe-Zone") {
                let level = localStorage.getItem("current_level");
                if (level === localStorage.getItem("max_levels")){
                    displayWin();
                }
                else{
                    level++;
                    localStorage.setItem("current_level", level);
                    this.map = new Map();
                    pikachuX = 0;
                    pikachuY = 0;
                    sandShrewX = 40;
                    sandShrewY = 40;
                }
            }
        }
        if (pikachuX < sandShrewX+ 29 &&
            pikachuX + 29 > sandShrewX &&
            pikachuY < sandShrewY + 37 &&
            32 + pikachuY> sandShrewY)
        {
            health-= 0.2;
            localStorage.setItem("health", health);
        }
        //For reference to detect collision
        /*
            * (rect1.x < rect2.x + rect2.width &&
       rect1.x + rect1.width > rect2.x &&
       rect1.y < rect2.y + rect2.height &&
       rect1.y + rect1.height > rect2.y)*/

        marowakX = Math.floor((Math.random() * 400) + 1);
        marowakY = Math.floor((Math.random() * 400) + 1);
        if (pikachuX < marowakX+ 55 &&
            pikachuX + 29 > marowakX &&
            pikachuY < marowakY + 50 &&
            32 + pikachuY> marowakY)
        {
            health-= 0.5;
            localStorage.setItem("health", health);
        }
        raichuMove();
        charmanderMove();
        charizardMove();
        squirtleMove();
    };

    function itemCollide()
    {
        if (pikachuX < watermelonX+25 &&
            pikachuX + 29 > watermelonX &&
            pikachuY < watermelonY + 22 &&
            32 + pikachuY> watermelonY)
        {
            health += 10.0;
            localStorage.setItem("health", health);
            watermelonX = 9999;
            watermelonY = 9999;
        }
        if (pikachuX < appleX+25 &&
            pikachuX + 29 > appleX &&
            pikachuY < appleY + 22 &&
            32 + pikachuY> appleY)
        {
            health += 15.0;
            localStorage.setItem("health", health);
            appleX = 9999;
            appleY = 9999;
        }
        if (pikachuX < chickenX+25 &&
            pikachuX + 29 > chickenX &&
            pikachuY < chickenY + 22 &&
            32 + pikachuY> chickenY)
        {
            health += 45.0;
            localStorage.setItem("health", health);
            chickenX = 9999;
            chickenY = 9999;
        }
        if (pikachuX < rchickenX+25 &&
            pikachuX + 29 > rchickenX &&
            pikachuY < rchickenY + 22 &&
            32 + pikachuY> rchickenY)
        {
            health -= 45.0;
            localStorage.setItem("health", health);
            rchickenX = 9999;
            rchickenY = 9999;
        }
        if (pikachuX < gappleX+25 &&
            pikachuX + 29 > gappleX &&
            pikachuY < gappleY + 22 &&
            32 + pikachuY> gappleY)
        {
            health += 50.0;
            localStorage.setItem("health", health);
            gappleX = 9999;
            gappleY = 9999;
        }
        if (pikachuX < pinkPowderX+25 &&
            pikachuX + 29 > pinkPowderX &&
            pikachuY < pinkPowderY + 22 &&
            32 + pikachuY> pinkPowderY)
        {
            health += 30.0;
            localStorage.setItem("health", health);
            pinkPowderX = 9999;
            pinkPowderY = 9999;
        }
        if (pikachuX < purplePowderX+25 &&
            pikachuX + 29 > purplePowderX &&
            pikachuY < purplePowderY + 22 &&
            32 + pikachuY> purplePowderY)
        {
            let random = Math.floor(Math.random() * 10);
            console.log(random);
            if(random % 2 === 0)
            {
                health += 30.0;
            }

            if(random % 2 === 1)
            {
                health -= 30.0;
            }
            localStorage.setItem("health", health);
            purplePowderX = 9999;
            purplePowderY = 9999;
        }
        if (pikachuX < cakeX+25 &&
            pikachuX + 29 > cakeX &&
            pikachuY < cakeY + 22 &&
            32 + pikachuY> cakeY)
        {
           currentSpeed /= 1.5;

            localStorage.setItem("speed", currentSpeed);
            cakeX = 9999;
            cakeY = 9999;
        }
        if (pikachuX < carrotX+25 &&
            pikachuX + 29 > carrotX &&
            pikachuY < carrotY + 22 &&
            32 + pikachuY> carrotY)
        {
            currentSpeed *= 1.5;

            localStorage.setItem("speed", currentSpeed);
            carrotX = 9999;
            carrotY = 9999;
        }
    }

    function raichuMove()
    {
          raichuX = Math.min(raichuX+5, 800-100);

          if(raichuX === 800-100)
            {
                raichuX = Math.min(400, raichuX-5);
            }

            if (pikachuX < raichuX + 65 &&
                pikachuX + 29 > raichuX &&
                pikachuY < raichuY + 53 &&
                32 + pikachuY > raichuY)
            {
                health-=0.4;
                localStorage.setItem("health", health);
            }

    };
    function charmanderMove()
    {
        charmanderY -= 5;

        if(charmanderY === 0)
        {
            health-=0.4;
            charmanderY = 390;
        }
        if (pikachuX < charmanderX + 29 &&
            pikachuX + 29 > charmanderX &&
            pikachuY < charmanderY + 37 &&
            32 + pikachuY > charmanderY)
        {
            health-=0.3;
            localStorage.setItem("health", health);
        }
        marowakX = Math.floor((Math.random() * 500) + 1);
        marowakY = Math.floor((Math.random() * 500) + 1);
    };

    function squirtleMove()
    {
        if(squirtleY !== 0)
        {
            squirtleY -= 10;
        }
        if(squirtleY === 0)
        {
           squirtleX += 10;
        }
        if(squirtleX === 770)
        {
            squirtleY += 10;
        }
        if(squirtleX === 770 && squirtleY >= 10 && squirtleY < 770)
        {
            squirtleY+= 10;
        }
        if(squirtleX === 770 && squirtleY === 770)
        {
            squirtleX-=10;
        }
        if(squirtleX <= 760 && squirtleX > 0 && squirtleY !== 0)
        {
            squirtleY = 770;
            squirtleX-=10;

        }
        if (pikachuX < squirtleX+ 38 &&
            pikachuX + 29 > squirtleX &&
            pikachuY < squirtleY+ 37 &&
            32 + pikachuY > squirtleY)
        {
            health-=0.3;
            localStorage.setItem("health", health);
        }
        marowakX = Math.floor((Math.random() * 600) + 1);
        marowakY = Math.floor((Math.random() * 600) + 1);

    };

    function charizardMove()
    {

        if(charizardY !== 20)
        {
            charizardY -= 10;
        }
        if(charizardY === 20)
        {
            charizardX += 10;
        }
        if(charizardX === 670)
        {
            charizardY += 10;
        }
        if(charizardX === 670 && charizardY >= 30 && charizardY < 670)
        {
            charizardY+= 20;
        }
        if(charizardX === 670 && charizardY === 670)
        {
            charizardX-=10;
        }
        if(charizardX <= 660 && charizardX > 20 && charizardY !== 20)
        {
            charizardY = 670;
            charizardX-=10;

        }
        if (pikachuX < charizardX+ 70 &&
            pikachuX + 29 > charizardX &&
            pikachuY < charizardY+ 70 &&
            32 + pikachuY > charizardY)
        {
            health-=1.5;
            localStorage.setItem("health", health);
        }
        marowakX = Math.floor((Math.random() * 600) + 1);
        marowakY = Math.floor((Math.random() * 600) + 1);
    }

    //Renders Player onto the map
    GameState.prototype.render = function(g){
        this.map.render(g);
        //Renders Player
        g.myDrawImage(Assets.getAssets("pikachu").idle, pikachuX,pikachuY, Assets.getAssets("pikachu").width, Assets.getAssets("pikachu").height);
        //Renders monsters
        g.myDrawImage(Assets.getAssets("raichu").monster, raichuX,raichuY, Assets.getAssets("raichu").width, Assets.getAssets("raichu").height);
        g.myDrawImage(Assets.getAssets("charmander").monster, charmanderX,charmanderY, Assets.getAssets("charmander").width, Assets.getAssets("charmander").height);
        g.myDrawImage(Assets.getAssets("squirtle").monster, squirtleX,squirtleY, Assets.getAssets("squirtle").width, Assets.getAssets("squirtle").height);
        g.myDrawImage(Assets.getAssets("sandshrew").monster, sandShrewX,sandShrewY, Assets.getAssets("sandshrew").width, Assets.getAssets("sandshrew").height);
        g.myDrawImage(Assets.getAssets("marowak").monster, marowakX,marowakY,Assets.getAssets("marowak").width, Assets.getAssets("marowak").height);
        g.myDrawImage(Assets.getAssets("charizard").monster, charizardX,charizardY,Assets.getAssets("charizard").width, Assets.getAssets("charizard").height);

        //Renders items
        g.myDrawImage(Assets.getAssets("watermelon").item, watermelonX,watermelonY, Assets.getAssets("watermelon").width, Assets.getAssets("watermelon").height);
        g.myDrawImage(Assets.getAssets("pinkPowder").item, pinkPowderX,pinkPowderY, Assets.getAssets("pinkPowder").width, Assets.getAssets("pinkPowder").height);
        g.myDrawImage(Assets.getAssets("purplePowder").item, purplePowderX,purplePowderY, Assets.getAssets("purplePowder").width, Assets.getAssets("purplePowder").height);
        g.myDrawImage(Assets.getAssets("cake").item, cakeX,cakeY, Assets.getAssets("cake").width, Assets.getAssets("cake").height);
        g.myDrawImage(Assets.getAssets("carrot").item, carrotX,carrotY, Assets.getAssets("carrot").width, Assets.getAssets("carrot").height);
        g.myDrawImage(Assets.getAssets("apple").item, appleX,appleY, Assets.getAssets("apple").width, Assets.getAssets("apple").height);
        g.myDrawImage(Assets.getAssets("gapple").item, gappleX,gappleY, Assets.getAssets("gapple").width, Assets.getAssets("gapple").height);
        g.myDrawImage(Assets.getAssets("chicken").item, chickenX,chickenY, Assets.getAssets("chicken").width, Assets.getAssets("chicken").height);
        g.myDrawImage(Assets.getAssets("rchicken").item, rchickenX,rchickenY, Assets.getAssets("rchicken").width, Assets.getAssets("rchicken").height);
    };

    return GameState;
});
