
define(['Class'], function(Class)
{
   var keys = [];
   var KeyManager = Class.extend({
      init: function(){

      }
   });

   KeyManager.prototype.tick = function(){
        this.up = keys[87]; //w
        this.down = keys[83];//s
        this.left = keys[65];//a
        this.right = keys[68];//d
   };

   window.onkeypress = function(e)
   {
       var x = e.key;
       if(x === "w")
       {
           keys[87] = true;
       }
       if(x === "s")
       {
           keys[83] = true;
       }
       if(x === "a")
       {
           keys[65] = true;
       }
       if(x === "d")
       {
           keys[68] = true;
       }

   };
    window.onkeyup = function(e)
    {
        var x = e.key;
        if(x === "w")
        {
            keys[87] = false;
        }
        if(x === "s")
        {
            keys[83] = false;
        }
        if(x === "a")
        {
            keys[65] = false;
        }
        if(x === "d")
        {
            keys[68] = false;
        }
    };

    return KeyManager;
});