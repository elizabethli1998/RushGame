/*
Creates necessary terrains in the Terrain class
 */
define(['Terrain', 'Assets'], function (Terrain, Assets) {
    var assets = Assets.getAssets("terrains");
    var assets1 = Assets.getAssets("raichu");
    // Creates a walk asset in the Terrain.terrain array
    new Terrain(assets.walk, "Walk");
    // Creates a safe-zone asset in the Terrain.terrain array
    new Terrain(assets.safezone, "Safe-Zone");
    // Creates a barrier asset in the Terrain.terrain array
    new Terrain(assets.barrier, "barrier");
    new Terrain(assets1.monster, "monster");
   return Terrain
});