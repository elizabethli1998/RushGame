define(['Class', 'CreateTerrains', 'Levels'], function (Class, Terrain, Levels) {

    var Map = Class.extend({
        // Initializes the Map object
        init:function () {
            this.map = [];
            this.width = 800 / 32;
            this.height = 800 / 32;
            this.do_double_array();
            this.levels = new Levels();
            this.generate_map();
            localStorage.setItem("width", this.width * 32);
            localStorage.setItem("height", this.height * 32);
        },

        // Generates the 25x25 map using pre-defined maps
        generate_map:function () {
            this.map = this.levels.get_level(localStorage.getItem("current_level"));
        },

        // Generates the 25x25 map using helper methods
        randomly_generate_map:function () {
            this.generate_safe_zone();
            this.generate_barriers();
            this.generate_path();

        },
        // Generates the path for the player to walk to
        generate_path:function () {
            for(let row = 0; row < this.height; row++){
                for(let col = 0; col < this.width; col++){
                    if(this.map[row][col] == null){
                        this.map[row][col] = "Walk";
                    }
                }
            }
        },
        // Randomly generates the safe-zone for the player to get to
        generate_safe_zone:function () {
            let x = Math.floor(Math.random() * this.width);
            let y = Math.floor(Math.random() * this.height);
            this.map[y][x] = "Safe-Zone";

        },
        // Randomly generates the barriers for the player to avoid
        generate_barriers:function(){
            let num_of_barriers = Math.floor((Math.random() * 18) + 16);
            while(num_of_barriers !== 0){
                let x = Math.floor(Math.random() * this.width);
                let y = Math.floor(Math.random() * this.height);
                if(this.where_to_place_barrier(y, x) === 1){
                    this.map[y][x] = "barrier";
                    this.map[y - 1][x] = "barrier";
                    num_of_barriers--;
                }
                else if(this.where_to_place_barrier(y, x) === 2){
                    this.map[y][x] = "barrier";
                    this.map[y][x + 1] = "barrier";
                    num_of_barriers--;
                }
                else if(this.where_to_place_barrier(y, x) === 3){
                    this.map[y][x] = "barrier";
                    this.map[y + 1][x] = "barrier";
                    num_of_barriers--;
                }
                else if(this.where_to_place_barrier(y, x) === 4){
                    this.map[y][x] = "barrier";
                    this.map[y][x - 1] = "barrier";
                    num_of_barriers--;
                }
                else if(this.where_to_place_barrier(y, x) === 0){
                    this.map[y][x] = "barrier";
                    num_of_barriers--;
                }
            }
        },
        // Gives a direction to place barriers. Helper function generate_barriers
        where_to_place_barrier: function(given_row, given_col){
            let i = 0;
            let side = [];
            if(this.map[given_row][given_col] === null){
                if(this.map[given_row][given_col] === null){
                    side[i++] =  0;
                }
                if(given_row - 1 >= 0 && this.map[given_row - 1][given_col] === null){
                    side[i++] =  1;
                }
                if(given_col + 1 < this.width && this.map[given_row][given_col + 1] === null){
                    side[i++] = 2;
                }
                if(given_row + 1 < this.height && this.map[given_row + 1][given_col] === null){
                    side[i++] = 3;
                }
                if(given_col - 1 >= 0 && this.map[given_row][given_col - 1] === null){
                    side[i++] = 4;
                }
            }

            if(side.length === 1){
                return null;
            }
            let ran_index = Math.floor(Math.random() * i);
            return side[ran_index];
        },
        // Creates a double array from the map variable. Nothing fancy but two for loops
        do_double_array:function(){
            for(let row = 0; row < this.height; row++){
                this.map[row] = [];
                for(let col = 0; col < this.width; col++){
                    this.map[row][col] = null;
                }
            }
        },
        // Renders each terrain cell using the for-loop. Look into Terrain.js for more information on how its being
        // rendered
        render:function (given_graphics) {
            for(let row = 0; row < this.height; row++){
                for(let col = 0; col < this.width; col++){
                    this.getTerrain(row, col).render(given_graphics, row, col);
                }
            }
        },
        // Retrieves the respectable Terrain object
        getTerrain:function (given_row, given_col) {
            return Terrain.terrains[this.map[given_row][given_col]];
        }
    });

    return Map;
});