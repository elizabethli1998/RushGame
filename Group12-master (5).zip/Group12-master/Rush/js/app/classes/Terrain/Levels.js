define(['Class', 'CreateTerrains'], function (Class, Terrain) {

    var Levels = Class.extend({
        // Initializes the Level object
        init:function () {
            this.levels = [];
            this.width = 800 / 32;
            this.height = 800 / 32;
            localStorage.setItem("max_levels", '5');
            this.generate_levels();
        },

        //Returns the specified level from the levels array
        get_level:function (given_level) {
            return this.levels[given_level - 1];
        },

        //Generates each level and stores them in levels array
        generate_levels:function() {
            this.levels[0] = this.generate_level_one();
            this.levels[1] = this.generate_level_two();
            this.levels[2] = this.generate_level_three();
            this.levels[3] = this.generate_level_four();
            this.levels[4] = this.generate_level_five();
        },

        generate_level_one:function () {
            let new_level = [
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Safe-Zone", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"]
            ];
            return new_level;
        },

        generate_level_two:function () {
            let new_level = [
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Safe-Zone", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"]
            ];
            return new_level;
        },

        generate_level_three:function () {
            let new_level = [
                ["Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "Safe-Zone", "Walk"],
                ["barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk"]
            ];
            return new_level;
        },

        generate_level_four:function () {
            let new_level = [
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Safe-Zone", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"]
            ];
            return new_level;
        },

        generate_level_five:function () {
            let new_level = [
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Safe-Zone", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "barrier", "barrier"],
                ["Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "barrier", "Walk", "Walk"],
                ["barrier", "barrier", "barrier", "barrier", "Walk", "Walk", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "barrier", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"],
                ["Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk", "Walk"]
            ];
            return new_level;
        }
    });
    return Levels;
});