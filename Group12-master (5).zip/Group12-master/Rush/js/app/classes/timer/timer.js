//Timer that counts up


//NOTE: EVERYTHING HERE IS MOVED TO GAMEOFSTATE

//Holds min and second
var min = 0;
var second = 0.0;
var display;
var healthTime = 0;
var currentHealth = 100;
var currentSpeed = 50;
localStorage.setItem("health",currentHealth);
localStorage.setItem("speed", currentSpeed);

var textBox = document.createElement("div");
var css = "ul {list-style-type: none;margin: 0;padding: 0;overflow: hidden;}";
var stat = "<ul id= \"stats\">" +
    "<li id = \"time\">time</li>" +
    "<li id = \"playerLocation\">Player Location: [0,0]</li>" +
    "<li id = \"speed\">Speed\: 30</li>" +
    "<li id = \"health\">Health\: 100/100</li>" +
  //  "<li id = \"monstersRemaining\">Monsters Remaining\: 5</li>" +
    "</ul>";

//Holds the interval for the timer
var interval;

//Constructor
function TimerRun(Display) {
    display = Display;
    display.getCanvas().insertAdjacentElement('beforebegin', textBox);
    display.getCanvas().insertAdjacentHTML('beforebegin', stat);
    document.getElementById("time").innerText = "00:00";
    document.getElementsByTagName("ul")[0].style.listStyleType = "none";
    document.getElementsByTagName("ul")[0].style.margin = "0";
    document.getElementsByTagName("ul")[0].style.padding = "0";
    document.getElementsByTagName("ul")[0].style.overflow = "hidden";

    for(let i = 0; i < 4; i++){
        document.getElementsByTagName("li")[i].style.cssFloat = "left";
        document.getElementsByTagName("li")[i].style.padding = "10px";
    }

    document.getElementById("health").style.color = "green";
    currentHealth = localStorage.getItem("health");
    //If the start button has been clicked already a new interval won't be added
    //and the timer will be reset
    if(!interval){
        interval = setInterval(upCountTimer, 1000);
    }
    else{
        resetTimer();
    }
}

//Starts the up count for the timer
function upCountTimer(){
    ++second;
    healthTime = healthTime + 0.5;

    currentHealth = localStorage.getItem("health");
    currentSpeed = localStorage.getItem("speed");
    document.getElementById("speed").innerText = "Speed: " + currentSpeed;
    document.getElementById("health").innerText = "Health: "+ Math.round(currentHealth) +"/100";

    if (currentHealth <= 100 && currentHealth >= 70){
        document.getElementById("health").style.color = "green";
    }
    else if(currentHealth < 70 && currentHealth >= 40){
        document.getElementById("health").style.color = "orange";
    }
    else if(currentHealth < 40 && currentHealth >= 0){
        document.getElementById("health").style.color = "red";
    }

    //Sets seconds back to zero when 60 is reached, adds 1 to min
    if(second % 60 === 0){
        second = 0;
        min++;
    }

    if(min === 5)
    {
        document.getElementById("health").textContent = "You lose...Press spacebar to return to Dashboard";
        stopTimer();
        window.alert("Lose!");
        document.body.onkeyup = function(e){
            if(e.keyCode == 32){
                window.location.href = 'index.html';
            }
        }
    }

    if(currentHealth === 0 || currentHealth < 0)
    {
        document.getElementById("health").textContent = "You lose...Press spacebar to return to Dashboard";
        stopTimer();
        window.alert("Lose!");
        document.body.onkeyup = function(e){
            if(e.keyCode == 32){
                window.location.href = 'index.html';
            }
        }
    }

    displayTime();
}

//Stops the timer;
function stopTimer(){
    clearInterval(interval);
    interval = null;
}

//Displays the timer in the correct format
function displayTime(){

    //Formats min and second to always be double digits
    var formattedMin = ("0" + min).slice(-2);
    var formattedSecond = ("0" + second).slice(-2);

    //Formats the timer and displays
    let finalTime = formattedMin + ":" + formattedSecond;
    document.getElementById("time").innerText = finalTime;
    if(finalTime === "05:00")
    {
        document.getElementById("health").textContent = "You lose...Press spacebar to return to Dashboard";
        stopTimer();
        document.body.onkeyup = function(e){
            if(e.keyCode == 32){
                window.location.href = 'index.html';
            }
        }
    }
}

//Resets the timer back to zero
function resetTimer(){
    min = 0;
    second = 0;
    displayTime();
}

//Displays the coordinates of the player
function displayCoor(playerX, playerY){

    //Formats the timer and displays
    let finalCoor = "[" + playerX + "," + playerY +"]";
    document.getElementById("playerLocation").innerText = finalCoor;
}

//Displays when the player wins
function displayWin() {
    stopTimer();
    window.alert("WIN!!!");
}


