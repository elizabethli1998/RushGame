
define(['Class','Display','Timer','State','GameState','KeyManager','Handler'], function(Class, Display, Timer, State, GameState,KeyManager, Handler)
{
    var _this;
    var running = false;
    var title,width,height,g, keyManager, handler;

    var gameState, menuState, settingsState, time;

   var Game = Class.extend({

       init:function(_title,_width,_height)
       {
               _this = this;
               title = _title;
               width = _width;
               height = _height;
               keyManager = new KeyManager();
       }
   });
    function init()
    {
        display = new Display(title,width,height);
        g = display.getGraphics();
        handler = new Handler(_this);
        gameState = new GameState(handler);
        State.setState(gameState);
        //display.getCanvas().insertAdjacentHTML('beforebegin', "<h2>Test</h2>");
        //display.
        TimerRun(display);
    }
    function tick(td)
    {
        keyManager.tick();
        if(State.getState() != null)
        {
            State.getState().tick(td);
        }
    }

    function render()
    {
        g.clearRect(0, 0, width, height);
        if(State.getState() != null)
        {
            State.getState().render(g);
        }
        // g.drawImage(img, 20, 20);
    }
    var x = 20;
    var y = 30;
   // var img = ImageLoader.loadImage("https://vignette.wikia.nocookie.net/virtuadopt/images/5/56/Charmander.png/revision/latest?cb=20111217191014");

    Game.prototype.run = function()
    {
        init();
        var fps = 30;
        var timePerTick = 1000/fps;
        var change = 0;
        var current;
        var prevTime = Date.now();
        var timer = 0;
        var ticks = 0;
        function loop(){
            if(running)
            {
                current = Date.now();
                change = current - prevTime;
                timer += change;
                prevTime = current;
            }
            if(timer>= timePerTick)
            {
                dt = timer/1000;
                tick(dt);
                render();
                timer = 0;
            }
            window.requestAnimationFrame(loop);
        }
        loop();
    };
    Game.prototype.start = function(){
        if(running) return;
        running = true;
        this.run();
    };
    Game.prototype.getWidth = function()
    {
        return width;
    };
    Game.prototype.getKeyManager = function()
    {
        return keyManager;
    };
    Game.prototype.getHeight = function()
    {
        return height;
    };

    return Game;
});