//Timer that counts up

//Holds min and second
var min = 0;
var second = 0.0;
var display;
var healthTime = 0;
var currentHealth = 100;
var textBox = document.createElement("div");
var css = "ul {list-style-type: none;margin: 0;padding: 0;overflow: hidden;}";
var stat = "<ul id= \"stats\">" +
    "<li id = \"time\">time</li>" +
    "<li id = \"playerLocation\">Player Location: [0,0]</li>" +
    "<li id = \"health\">Health\: 100/100</li>" +
    "<li id = \"monstersRemaining\">Monsters Remaining\: 0</li>" +
    "</ul>";

//Holds the interval for the timer
var interval;

//Constructor
function TimerRun(Display) {
    display = Display;
    display.getCanvas().insertAdjacentElement('beforebegin', textBox);
    display.getCanvas().insertAdjacentHTML('beforebegin', stat);
    document.getElementById("time").innerText = "00:00";
    document.getElementsByTagName("ul")[0].style.listStyleType = "none";
    document.getElementsByTagName("ul")[0].style.margin = "0";
    document.getElementsByTagName("ul")[0].style.padding = "0";
    document.getElementsByTagName("ul")[0].style.overflow = "hidden";

    for(let i = 0; i < 4; i++){
        document.getElementsByTagName("li")[i].style.cssFloat = "left";
        document.getElementsByTagName("li")[i].style.padding = "10px";
    }

    document.getElementById("health").style.color = "green";

    //If the start button has been clicked already a new interval won't be added
    //and the timer will be reset
    if(!interval){
        interval = setInterval(upCountTimer, 1000);
    }
    else{
        resetTimer();
    }
}

//Starts the up count for the timer
function upCountTimer(){
    ++second;
    healthTime = healthTime + 0.5;

    if (healthTime% 1.5 == 0 && currentHealth != 0){
        currentHealth = currentHealth - 1;
        document.getElementById("health").innerText = "Health: "+currentHealth +"/100"
    }

    if (currentHealth <= 100 && currentHealth >= 70){
        document.getElementById("health").style.color = "green";
    }
    else if(currentHealth < 70 && currentHealth >= 40){
        document.getElementById("health").style.color = "orange";
    }
    else if(currentHealth < 40 && currentHealth >= 0){
        document.getElementById("health").style.color = "red";
    }

    //Sets seconds back to zero when 60 is reached, adds 1 to min
    if(second % 60 === 0){
        second = 0;
        min++;
    }

    displayTime();
}

//Stops the timer;
function stopTimer(){
    clearInterval(interval);
    interval = null;
}

//Displays the timer in the correct format
function displayTime(){

    //Formats min and second to always be double digits
    var formattedMin = ("0" + min).slice(-2);
    var formattedSecond = ("0" + second).slice(-2);

    //Formats the timer and displays
    let finalTime = formattedMin + ":" + formattedSecond;
    document.getElementById("time").innerText = finalTime;
}

//Resets the timer back to zero
function resetTimer(){
    min = 0;
    second = 0;

    displayTime();
}




