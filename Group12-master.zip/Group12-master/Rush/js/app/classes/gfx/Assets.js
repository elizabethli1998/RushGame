
define(['Class', 'ImageLoader', 'SpriteSheet'], function(Class, ImageLoader, SpriteSheet)
{
    var default_width = 32;
    var default_height = 32;
    var assets = {};
    var sheet;
    var Assets = Class.extend({
        init:function(name1, path1, width1, height1)
        {
            assets[name1] = this;
            this.name = name1;
            this.path = path1;
            this.width = width1;
            this.height = height1;
            this.sheet = new SpriteSheet(ImageLoader.loadImage(this.path));
        }
        });

        Assets.default_width = default_width;
        Assets.default_height = default_height;

        Assets.getAssets = function(name1){
            return assets[name1];
        };

    var asset = new Assets("pikachu", "res/textures/pikachusprites.png", 29, 32);
    asset.idle = asset.sheet.crop(0,0,29,32);

    // Creating terrain walk and safe-zone image assets
    var terrains = new Assets("terrains", "res/textures/terrain.png", 64, 64);
    terrains.walk = terrains.sheet.crop(0, terrains.height * 1, terrains.width, terrains.height);
    terrains.safezone = terrains.sheet.crop(terrains.width * 8, terrains.height * 1, terrains.width, terrains.height);
    terrains.barrier = terrains.sheet.crop(terrains.width * 8, terrains.height * 0, terrains.width, terrains.height);

    return Assets;
});
