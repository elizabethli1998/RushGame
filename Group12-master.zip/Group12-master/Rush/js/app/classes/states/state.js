
define(['Class'], function(Class){
    var stateNow = null;

    var State = Class.extend({
       init:function(_handler){
            this.handler = _handler;
       }
    });

    State.prototype.tick = function(dt)
    {

    };
    State.prototype.render = function(g)
    {

    };

    State.getState = function(){
        return stateNow;
    };
    State.setState = function(state1)
    {
        stateNow = state1;
    }
    return State
});