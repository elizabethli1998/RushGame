

define(['State', 'Assets', 'Map'], function(State, Assets, Map)
{
    var GameState = State.extend({
        init:function(_handler)
        {
            this._super(_handler);
            this.map = new Map();
        }
    });
    var x = 0;
    var y = 0;

    var idle = Assets.getAssets("pikachu").idle;
    GameState.prototype.tick = function(_dt){
        if(this.handler.getKeyManager().up)
        {
            y -= 30 * _dt;
        }
        if(this.handler.getKeyManager().down)
        {
            y += 30 * _dt;
        }
        if(this.handler.getKeyManager().left)
        {
            x -= 30 * _dt;
        }
        if(this.handler.getKeyManager().right)
        {
            x += 30 * _dt;
        }
    };
    GameState.prototype.render = function(g){
       this.map.render(g);
        g.myDrawImage(Assets.getAssets("pikachu").idle, x,y, Assets.getAssets("pikachu").width, Assets.getAssets("pikachu").height);
    };

    return GameState;
});
