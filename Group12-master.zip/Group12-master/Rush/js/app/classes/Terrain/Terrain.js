/*
Class is mainly used to store an array of Terrain objects. AllTerrains is later used to create the terrains the project
needs from the Asset class
 */
define(['Class'], function (Class) {

    // Initializes constant variables for the terrain object
    var terrains = [];

    var Terrain = Class.extend({
        // Floor and type are variables that make the terrain unique in the map
        init:function (given_floor, given_type) {
            this.floor = given_floor;
            this.type = given_type;
            terrains[this.type] = this;
        },
        // Function will be used to render an image in the html using given_graphics.
        // given_graphics comes from Display class and has access to the canvas
        render:function (given_graphics, given_row, given_col){
            given_graphics.myDrawImage(this.floor, given_row * 32, given_col * 32, 32, 32);
        }
    });

    // Terrain object soon returned needs to know about in its class
    Terrain.terrains = terrains;

    return Terrain;
});