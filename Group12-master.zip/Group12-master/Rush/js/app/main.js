

require(['Launcher'],function(Launcher){

    var launcher = new Launcher("Rush",800,800);
});